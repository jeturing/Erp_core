.. image:: https://img.shields.io/badge/license-AGPL--3-blue.svg
    :target: http://www.gnu.org/licenses/agpl-3.0-standalone.html
    :alt: License: AGPL-3

Beauty Spa Management
=====================
This module to helps your customers to do the online booking for using the
service. This module integrates with other Odoo modules like accounting and
website.

Configuration
============
- www.odoo.com/documentation/17.0/setup/install.html
- Install our custom addon

Company
-------
* `Cybrosys Techno Solutions <https://cybrosys.com/>`__

License
-------
General Public License, Version 3 (AGPL V3).
(http://www.gnu.org/licenses/agpl-3.0-standalone.html)

Credits
-------
Developer: (V17) Mohammed Dilshad Tk, Contact: odoo@cybrosys.com

Contacts
--------
* Mail Contact : odoo@cybrosys.com
* Website : https://cybrosys.com

Bug Tracker
-----------
Bugs are tracked on GitHub Issues. In case of trouble, please check there if your issue has already been reported.

Maintainer
==========
.. image:: https://cybrosys.com/images/logo.png
   :target: https://cybrosys.com

This module is maintained by Cybrosys Technologies.

For support and more information, please visit `Our Website <https://cybrosys.com/>`__

Further information
===================
HTML Description: `<static/description/index.html>`__

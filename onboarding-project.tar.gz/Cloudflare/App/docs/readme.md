# Sistema de Onboarding Automatizado con Stripe

## 📋 Resumen del Proyecto

Sistema completo de onboarding automatizado para clientes que integra:
- **Formulario web de registro** con interfaz moderna
- **Integración con Stripe** para procesamiento de pagos
- **Aprovisionamiento automático** de tenants Odoo multitenant
- **Gestión de túneles Cloudflare** para dominios personalizados
- **Base de datos PostgreSQL** para gestión de clientes y suscripciones

---

## 🏗️ Arquitectura del Sistema

```
┌─────────────────────────────────────────────┐
│         Internet / Stripe Webhooks          │
└─────────────────┬───────────────────────────┘
                  │ HTTPS (443)
┌─────────────────▼───────────────────────────┐
│     Cloudflare Tunnel (futuro routing)      │
│         onboarding.sajet.us                 │
└─────────────────┬───────────────────────────┘
                  │
┌─────────────────▼───────────────────────────┐
│   LXC 160 - SRV-ONBOARDING (172.16.16.160)  │
│  ┌─────────────────────────────────────┐   │
│  │  NGINX (Puerto 443 SSL + 80 HTTP)   │   │
│  │  - Certificado SSL autofirmado      │   │
│  │  - Proxy reverso a FastAPI          │   │
│  │  - Sirve templates HTML estáticos   │   │
│  └─────────────────┬───────────────────┘   │
│                    │                        │
│  ┌─────────────────▼───────────────────┐   │
│  │  FastAPI Application (Puerto 4443)  │   │
│  │  - API REST                         │   │
│  │  - Webhook handler de Stripe        │   │
│  │  - Provisionador de tenants Odoo    │   │
│  │  - Uvicorn ASGI server              │   │
│  └─────────────────┬───────────────────┘   │
│                    │                        │
│  ┌─────────────────▼───────────────────┐   │
│  │  PostgreSQL (Puerto 5432)           │   │
│  │  Database: onboarding_db            │   │
│  │  Usuario: jeturing / 321Abcd        │   │
│  │  Accesible desde red interna        │   │
│  │  - Tabla: customers                 │   │
│  │  - Tabla: subscriptions             │   │
│  │  - Tabla: stripe_events             │   │
│  └─────────────────────────────────────┘   │
└─────────────────┬───────────────────────────┘
                  │ SSH/API (172.16.16.105)
┌─────────────────▼───────────────────────────┐
│            LXC 105 - ODOO (Existente)       │
│  - PostgreSQL con usuario Jeturing          │
│  - Odoo 17 en puerto 8069                   │
│  - Script: /root/Cloudflare/create_tenant.sh│
│  - Túnel: tcs-sajet-tunnel                  │
└─────────────────────────────────────────────┘
```

---

## 🔧 Especificaciones Técnicas

### **LXC 160 - SRV-ONBOARDING**

**Recursos:**
- **ID:** 160
- **Hostname:** SRV-ONBOARDING
- **IP Interna:** 172.16.16.160
- **RAM:** 1024 MB (1 GB)
- **Disco:** 10 GB
- **OS:** Debian 12 (Bookworm)
- **CPU:** 2 cores
- **Acceso Root:** Usuario `root` / Contraseña `123Abcd`

**Puertos en Escucha:**
- **443** - NGINX HTTPS (SSL/TLS)
- **80** - NGINX HTTP (redirect a HTTPS)
- **4443** - FastAPI Application (interno)
- **5432** - PostgreSQL (accesible desde red interna)

---

## 📦 Stack Tecnológico Instalado

### **Backend:**
- **Python 3.11.2**
- **FastAPI 0.115.12** - Framework web moderno y rápido
- **Uvicorn 0.34.0** - Servidor ASGI de alto rendimiento
- **SQLAlchemy 2.0.37** - ORM para base de datos
- **Pydantic 2.10.5** - Validación de datos
- **Stripe 11.7.0** - SDK de pagos
- **Psycopg2 2.9.10** - Driver PostgreSQL
- **Python-dotenv 1.0.1** - Gestión de variables de entorno
- **Httpx 0.28.2** - Cliente HTTP asíncrono

### **Base de Datos:**
- **PostgreSQL 15.10**
- **Database:** `onboarding_db`
- **Usuario:** `jeturing`
- **Contraseña:** `321Abcd`
- **Configuración:** Accesible desde `172.16.16.0/24`

### **Web Server:**
- **NGINX 1.22.1**
- **Certificado SSL:** Autofirmado (365 días)
- **TLS:** 1.2 y 1.3
- **Proxy Reverso:** A FastAPI en puerto 4443

### **Herramientas:**
- **Git** - Control de versiones
- **curl** - Cliente HTTP
- **openssl** - Generación de certificados
- **jq** - Procesamiento JSON (para scripts bash)

---

## 📁 Estructura del Proyecto

```
/opt/onboarding-system/
├── app/
│   ├── __init__.py                  # Paquete principal
│   ├── main.py                      # Aplicación FastAPI principal
│   ├── models.py                    # Modelos SQLAlchemy y Pydantic
│   ├── database.py                  # Configuración de conexión DB
│   └── odoo_provisioner.py          # Servicio de aprovisionamiento
│
├── templates/
│   ├── index.html                   # Formulario de onboarding
│   └── success.html                 # Página de confirmación
│
├── static/
│   ├── css/
│   │   └── styles.css              # Estilos personalizados
│   └── js/
│       └── app.js                  # Lógica del frontend
│
├── venv/                            # Entorno virtual Python
│
├── requirements.txt                 # Dependencias Python
│
├── .env                             # Variables de entorno (secrets)
│
└── README.md                        # Documentación del proyecto

/etc/systemd/system/
└── onboarding.service               # Servicio systemd

/etc/nginx/
├── sites-available/
│   └── onboarding                   # Configuración nginx
├── sites-enabled/
│   └── onboarding -> ../sites-available/onboarding
└── ssl/
    ├── onboarding.crt               # Certificado SSL
    └── onboarding.key               # Llave privada SSL

/var/log/
└── onboarding.log                   # Logs de la aplicación
```

---

## 🗄️ Esquema de Base de Datos

### **Tabla: customers**

```sql
CREATE TABLE customers (
    id SERIAL PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    name VARCHAR(255) NOT NULL,
    company VARCHAR(255),
    phone VARCHAR(50),
    subdomain VARCHAR(100) UNIQUE,
    stripe_customer_id VARCHAR(255) UNIQUE,
    status VARCHAR(50) DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

**Campos:**
- `id` - Identificador único autoincremental
- `email` - Email del cliente (único)
- `name` - Nombre completo del cliente
- `company` - Nombre de la empresa
- `phone` - Teléfono de contacto
- `subdomain` - Subdominio asignado para tenant Odoo
- `stripe_customer_id` - ID del cliente en Stripe
- `status` - Estado: `pending`, `active`, `suspended`, `cancelled`
- `created_at` - Fecha de creación
- `updated_at` - Fecha de última actualización

### **Tabla: subscriptions**

```sql
CREATE TABLE subscriptions (
    id SERIAL PRIMARY KEY,
    customer_id INTEGER REFERENCES customers(id) ON DELETE CASCADE,
    stripe_subscription_id VARCHAR(255) UNIQUE,
    plan_name VARCHAR(100) NOT NULL,
    plan_price DECIMAL(10,2),
    status VARCHAR(50) DEFAULT 'active',
    current_period_start TIMESTAMP,
    current_period_end TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

**Campos:**
- `id` - Identificador único
- `customer_id` - Referencia al cliente (FK)
- `stripe_subscription_id` - ID de suscripción en Stripe
- `plan_name` - Nombre del plan contratado
- `plan_price` - Precio del plan
- `status` - Estado: `active`, `past_due`, `canceled`, `unpaid`
- `current_period_start` - Inicio del período de facturación
- `current_period_end` - Fin del período de facturación
- `created_at` - Fecha de creación
- `updated_at` - Fecha de última actualización

### **Tabla: stripe_events**

```sql
CREATE TABLE stripe_events (
    id SERIAL PRIMARY KEY,
    event_id VARCHAR(255) UNIQUE NOT NULL,
    event_type VARCHAR(100) NOT NULL,
    payload JSONB,
    processed BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

**Campos:**
- `id` - Identificador único
- `event_id` - ID del evento de Stripe (único)
- `event_type` - Tipo de evento (ej: `checkout.session.completed`)
- `payload` - Payload completo del webhook en formato JSON
- `processed` - Flag de procesamiento exitoso
- `created_at` - Fecha de recepción

---

## 🔌 API Endpoints

### **Base URL:** `https://172.16.16.160/api/v1`

### **1. Health Check**
```http
GET /health
```

**Response:**
```json
{
  "status": "healthy",
  "service": "onboarding-system",
  "database": "connected"
}
```

---

### **2. Listar Planes Disponibles**
```http
GET /api/v1/plans
```

**Response:**
```json
{
  "plans": [
    {
      "id": "basic",
      "name": "Plan Básico",
      "price": 29.99,
      "features": [
        "5 Usuarios",
        "10 GB Almacenamiento",
        "Soporte Email"
      ],
      "stripe_price_id": "price_xxxxx"
    },
    {
      "id": "pro",
      "name": "Plan Profesional",
      "price": 79.99,
      "features": [
        "25 Usuarios",
        "100 GB Almacenamiento",
        "Soporte Prioritario",
        "API Acceso"
      ],
      "stripe_price_id": "price_yyyyy"
    },
    {
      "id": "enterprise",
      "name": "Plan Empresarial",
      "price": 199.99,
      "features": [
        "Usuarios Ilimitados",
        "1 TB Almacenamiento",
        "Soporte 24/7",
        "API Ilimitado",
        "Personalización"
      ],
      "stripe_price_id": "price_zzzzz"
    }
  ]
}
```

---

### **3. Crear Sesión de Checkout Stripe**
```http
POST /api/v1/checkout
Content-Type: application/json
```

**Request Body:**
```json
{
  "email": "cliente@empresa.com",
  "name": "Juan Pérez",
  "company": "Mi Empresa SRL",
  "phone": "+1234567890",
  "subdomain": "miempresa",
  "plan_id": "pro"
}
```

**Validaciones:**
- `email`: Formato válido y único
- `subdomain`: Solo letras minúsculas, números y guiones (3-20 caracteres), único
- `plan_id`: Debe existir en planes configurados

**Response:**
```json
{
  "checkout_url": "https://checkout.stripe.com/c/pay/cs_test_xxxxx",
  "session_id": "cs_test_xxxxx",
  "customer": {
    "id": 1,
    "email": "cliente@empresa.com",
    "subdomain": "miempresa",
    "status": "pending"
  }
}
```

---

### **4. Webhook de Stripe**
```http
POST /webhook/stripe
Content-Type: application/json
Stripe-Signature: t=xxx,v1=yyy
```

**Eventos Procesados:**
- `checkout.session.completed` - Pago exitoso, aprovisiona tenant
- `customer.subscription.updated` - Actualiza estado de suscripción
- `customer.subscription.deleted` - Cancela suscripción
- `invoice.payment_failed` - Notifica fallo de pago

**Flujo de Provisioning (checkout.session.completed):**
1. Valida firma del webhook
2. Registra evento en `stripe_events`
3. Busca cliente por `stripe_customer_id`
4. Ejecuta script de aprovisionamiento:
   ```bash
   pct exec 105 -- bash -c "cd /root/Cloudflare && ./create_tenant.sh {subdomain}"
   ```
5. Actualiza estado del cliente a `active`
6. Crea registro en `subscriptions`
7. Envía email de bienvenida (futuro)

**Response:**
```json
{
  "received": true,
  "event_id": "evt_xxxxx"
}
```

---

### **5. Obtener Cliente**
```http
GET /api/v1/customers/{customer_id}
```

**Response:**
```json
{
  "id": 1,
  "email": "cliente@empresa.com",
  "name": "Juan Pérez",
  "company": "Mi Empresa SRL",
  "subdomain": "miempresa",
  "status": "active",
  "odoo_url": "https://miempresa.sajet.us",
  "subscription": {
    "plan_name": "Plan Profesional",
    "status": "active",
    "current_period_end": "2026-02-12T00:00:00Z"
  }
}
```

---

### **6. Listar Clientes**
```http
GET /api/v1/customers?status=active&page=1&limit=20
```

**Query Params:**
- `status` (opcional): `pending`, `active`, `suspended`, `cancelled`
- `page` (default: 1): Número de página
- `limit` (default: 20): Items por página

**Response:**
```json
{
  "total": 45,
  "page": 1,
  "limit": 20,
  "customers": [...]
}
```

---

## 🔐 Configuración de Stripe

### **Paso 1: Obtener API Keys**

1. Ingresar a [Stripe Dashboard](https://dashboard.stripe.com/test/apikeys)
2. Copiar las claves de **Test mode** (para pruebas) o **Live mode** (producción)
3. Copiar:
   - **Publishable key** (comienza con `pk_`)
   - **Secret key** (comienza con `sk_`)
   - **Webhook signing secret** (comienza con `whsec_`)

### **Paso 2: Configurar Variables de Entorno**

Editar archivo `/opt/onboarding-system/.env` en el LXC 160:

```bash
pct exec 160 -- nano /opt/onboarding-system/.env
```

Reemplazar los valores:

```env
# Stripe API Keys
STRIPE_PUBLISHABLE_KEY=pk_test_xxxxxxxxxxxxxxxxxxxxxxxx
STRIPE_SECRET_KEY=sk_test_xxxxxxxxxxxxxxxxxxxxxxxx
STRIPE_WEBHOOK_SECRET=whsec_xxxxxxxxxxxxxxxxxxxxxxxx

# Stripe Price IDs (crear productos en Stripe Dashboard)
STRIPE_PRICE_BASIC=price_xxxxx
STRIPE_PRICE_PRO=price_yyyyy
STRIPE_PRICE_ENTERPRISE=price_zzzzz

# PostgreSQL
DATABASE_URL=postgresql://jeturing:321Abcd@localhost:5432/onboarding_db

# Odoo LXC
ODOO_LXC_ID=105
ODOO_SCRIPT_PATH=/root/Cloudflare/create_tenant.sh
ODOO_DEFAULT_TUNNEL=tcs-sajet-tunnel
ODOO_DEFAULT_DOMAIN=sajet.us
```

### **Paso 3: Crear Productos y Precios en Stripe**

1. Ir a [Products](https://dashboard.stripe.com/test/products)
2. Click en **"+ Add product"**
3. Configurar cada plan:

**Plan Básico:**
- Name: `Plan Básico`
- Description: `5 usuarios, 10 GB almacenamiento`
- Price: `$29.99 USD` - Recurring monthly
- Copiar el `Price ID` generado (ej: `price_1Abc123`)

**Plan Profesional:**
- Name: `Plan Profesional`
- Description: `25 usuarios, 100 GB almacenamiento`
- Price: `$79.99 USD` - Recurring monthly
- Copiar el `Price ID`

**Plan Empresarial:**
- Name: `Plan Empresarial`
- Description: `Usuarios ilimitados, 1 TB almacenamiento`
- Price: `$199.99 USD` - Recurring monthly
- Copiar el `Price ID`

4. Actualizar los `Price IDs` en el archivo `.env`

### **Paso 4: Configurar Webhook en Stripe**

1. Ir a [Webhooks](https://dashboard.stripe.com/test/webhooks)
2. Click en **"+ Add endpoint"**
3. Configurar:
   - **Endpoint URL:** `https://DIRECCION_PUBLICA/webhook/stripe`
   - **Description:** `Onboarding System Webhook`
   - **Events to send:**
     - `checkout.session.completed`
     - `customer.subscription.updated`
     - `customer.subscription.deleted`
     - `invoice.payment_failed`
4. Click en **"Add endpoint"**
5. Copiar el **Signing secret** (comienza con `whsec_`)
6. Actualizar `STRIPE_WEBHOOK_SECRET` en `.env`

### **Paso 5: Reiniciar Servicio**

```bash
pct exec 160 -- systemctl restart onboarding
```

---

## 🚀 Flujo de Onboarding Completo

### **1. Cliente Accede al Formulario**
```
https://172.16.16.160/
```

### **2. Cliente Completa Formulario**
- Email
- Nombre completo
- Empresa
- Teléfono
- Subdominio deseado (ej: `miempresa`)
- Selecciona un plan

### **3. Sistema Valida Datos**
- Email único
- Subdominio disponible (no existe en BD ni en Odoo)
- Plan válido

### **4. Se Crea Cliente en BD**
```sql
INSERT INTO customers (email, name, company, phone, subdomain, status)
VALUES (..., 'pending');
```

### **5. Sistema Crea Stripe Checkout Session**
- Crea o encuentra Customer en Stripe
- Genera sesión de pago con metadata:
  ```json
  {
    "customer_id": "1",
    "subdomain": "miempresa",
    "plan_id": "pro"
  }
  ```
- Redirige al cliente a Stripe Checkout

### **6. Cliente Completa Pago en Stripe**
- Ingresa datos de tarjeta
- Stripe procesa el pago
- Stripe envía webhook `checkout.session.completed`

### **7. Sistema Recibe Webhook**
```
POST /webhook/stripe
```

### **8. Sistema Aprovisiona Tenant Odoo**

Ejecuta en LXC 105:
```bash
cd /root/Cloudflare
./create_tenant.sh miempresa
```

**El script ejecuta:**
1. Crea base de datos PostgreSQL `miempresa`
2. Limpia filestore de Odoo
3. Inicializa Odoo con módulo `base`
4. Configura `web.base.url` = `https://miempresa.sajet.us`
5. Enruta DNS en Cloudflare: `miempresa.sajet.us` → `tcs-sajet-tunnel`

### **9. Sistema Actualiza Estado**
```sql
UPDATE customers SET status = 'active' WHERE id = 1;

INSERT INTO subscriptions (customer_id, stripe_subscription_id, plan_name, status)
VALUES (1, 'sub_xxxxx', 'Plan Profesional', 'active');
```

### **10. Cliente Accede a su Tenant**
```
https://miempresa.sajet.us
```

Credenciales Odoo (default):
- **Usuario:** `admin`
- **Contraseña:** `admin` (debe cambiarse en primer acceso)

---

## 🛡️ Seguridad Implementada

### **SSL/TLS:**
- Certificado autofirmado para desarrollo
- TLS 1.2 y 1.3 habilitados
- Ciphers fuertes configurados
- Redirección automática HTTP → HTTPS

### **PostgreSQL:**
- Usuario no-root (`jeturing`)
- Contraseña compleja (`321Abcd`)
- Acceso limitado a red interna (`172.16.16.0/24`)
- Configurado en `/etc/postgresql/15/main/pg_hba.conf`

### **Stripe Webhooks:**
- Validación de firma obligatoria
- Verificación de timestamp (evita replay attacks)
- Idempotencia de eventos (tabla `stripe_events`)
- Logs de todos los eventos recibidos

### **API FastAPI:**
- CORS deshabilitado (solo acceso local/interno)
- Validación de inputs con Pydantic
- Manejo de errores robusto
- Logs estructurados

### **LXC Container:**
- Unprivileged container
- Nesting habilitado (para ejecutar comandos en LXC 105)
- Contraseña root fuerte
- Recursos limitados (1 GB RAM, 10 GB disco)

---

## 📝 Variables de Entorno Configuradas

Archivo: `/opt/onboarding-system/.env`

```env
# Stripe (REEMPLAZAR CON VALORES REALES)
STRIPE_PUBLISHABLE_KEY=pk_test_51XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
STRIPE_SECRET_KEY=sk_test_51XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
STRIPE_WEBHOOK_SECRET=whsec_XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
STRIPE_PRICE_BASIC=price_XXXXXXXXXXXXXXXXXXXXX
STRIPE_PRICE_PRO=price_XXXXXXXXXXXXXXXXXXXXX
STRIPE_PRICE_ENTERPRISE=price_XXXXXXXXXXXXXXXXXXXXX

# PostgreSQL
DATABASE_URL=postgresql://jeturing:321Abcd@localhost:5432/onboarding_db

# Odoo Integration
ODOO_LXC_ID=105
ODOO_SCRIPT_PATH=/root/Cloudflare/create_tenant.sh
ODOO_DEFAULT_TUNNEL=tcs-sajet-tunnel
ODOO_DEFAULT_DOMAIN=sajet.us

# Application
APP_ENV=production
LOG_LEVEL=INFO
```

---

## 🔄 Gestión del Servicio

### **Ver Estado**
```bash
pct exec 160 -- systemctl status onboarding
```

### **Iniciar Servicio**
```bash
pct exec 160 -- systemctl start onboarding
```

### **Detener Servicio**
```bash
pct exec 160 -- systemctl stop onboarding
```

### **Reiniciar Servicio**
```bash
pct exec 160 -- systemctl restart onboarding
```

### **Ver Logs en Tiempo Real**
```bash
pct exec 160 -- journalctl -u onboarding -f
```

### **Ver Últimos 100 Logs**
```bash
pct exec 160 -- journalctl -u onboarding -n 100 --no-pager
```

---

## 🗃️ Gestión de PostgreSQL

### **Conectarse a la Base de Datos**
```bash
pct exec 160 -- psql -U jeturing -d onboarding_db
```

### **Ver Clientes Registrados**
```sql
SELECT id, email, name, company, subdomain, status, created_at 
FROM customers 
ORDER BY created_at DESC 
LIMIT 10;
```

### **Ver Suscripciones Activas**
```sql
SELECT s.id, c.email, c.subdomain, s.plan_name, s.status, s.current_period_end
FROM subscriptions s
JOIN customers c ON s.customer_id = c.id
WHERE s.status = 'active'
ORDER BY s.created_at DESC;
```

### **Ver Eventos de Stripe Procesados**
```sql
SELECT event_id, event_type, processed, created_at
FROM stripe_events
ORDER BY created_at DESC
LIMIT 20;
```

### **Backup de Base de Datos**
```bash
pct exec 160 -- pg_dump -U jeturing onboarding_db > /root/backup_onboarding_$(date +%Y%m%d).sql
```

### **Restaurar Base de Datos**
```bash
cat /root/backup_onboarding_20260112.sql | pct exec 160 -- psql -U jeturing onboarding_db
```

---

## 🌐 Integración con Cloudflare Tunnel

### **Configurar Túnel para el Sistema de Onboarding**

Para hacer el sistema accesible públicamente:

```bash
cd /root/Cloudflare
./cc.sh
```

**Configuración recomendada:**
- **Dominio:** `sajet.us` (opción 4)
- **Subdominio:** `onboarding`
- **Puerto:** `443` (NGINX en LXC 160)

Esto creará:
- Túnel: `onboarding-sajet-tunnel`
- Hostname: `onboarding.sajet.us`
- Ruta: `onboarding.sajet.us` → `172.16.16.160:443`

### **Actualizar Webhook URL en Stripe**

Una vez configurado el túnel:

1. Ir a [Stripe Webhooks](https://dashboard.stripe.com/test/webhooks)
2. Editar el endpoint
3. Cambiar URL a: `https://onboarding.sajet.us/webhook/stripe`
4. Guardar cambios

---

## 🧪 Testing

### **1. Health Check**
```bash
curl -k https://172.16.16.160/health
```

Esperado:
```json
{
  "status": "healthy",
  "service": "onboarding-system",
  "database": "connected"
}
```

### **2. Ver Planes Disponibles**
```bash
curl -k https://172.16.16.160/api/v1/plans
```

### **3. Crear Cliente de Prueba**

```bash
curl -k -X POST https://172.16.16.160/api/v1/checkout \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "name": "Test User",
    "company": "Test Company",
    "phone": "+1234567890",
    "subdomain": "testcompany",
    "plan_id": "basic"
  }'
```

### **4. Verificar Conectividad PostgreSQL**

```bash
pct exec 160 -- psql -U jeturing -d onboarding_db -c "SELECT COUNT(*) FROM customers;"
```

### **5. Simular Webhook de Stripe (sin validación)**

⚠️ **Solo para desarrollo, NO usar en producción**

```bash
curl -k -X POST https://172.16.16.160/webhook/stripe \
  -H "Content-Type: application/json" \
  -d '{
    "id": "evt_test_webhook",
    "type": "checkout.session.completed",
    "data": {
      "object": {
        "id": "cs_test_123",
        "customer": "cus_test_123",
        "metadata": {
          "customer_id": "1",
          "subdomain": "testcompany"
        }
      }
    }
  }'
```

---

## 🐛 Troubleshooting

### **Problema: Servicio no inicia**

**Diagnóstico:**
```bash
pct exec 160 -- journalctl -u onboarding -n 50 --no-pager
```

**Posibles causas:**
1. Puerto 4443 en uso
2. Error en `.env` (API key inválida)
3. PostgreSQL no conecta

**Solución:**
```bash
# Verificar puerto
pct exec 160 -- ss -tlnp | grep 4443

# Verificar PostgreSQL
pct exec 160 -- systemctl status postgresql

# Reiniciar todo
pct exec 160 -- bash -c "systemctl restart postgresql && systemctl restart onboarding"
```

---

### **Problema: Error al crear cliente en Stripe**

**Error:** `StripeInvalidRequestError`

**Diagnóstico:**
```bash
pct exec 160 -- tail -100 /var/log/onboarding.log
```

**Solución:**
1. Verificar `STRIPE_SECRET_KEY` en `.env`
2. Confirmar que las keys sean de test mode si estás probando
3. Verificar que el plan_id exista en Stripe

---

### **Problema: Webhook no procesa eventos**

**Diagnóstico:**
```bash
pct exec 160 -- psql -U jeturing -d onboarding_db -c "SELECT * FROM stripe_events ORDER BY created_at DESC LIMIT 5;"
```

**Solución:**
1. Verificar `STRIPE_WEBHOOK_SECRET` en `.env`
2. Confirmar que el endpoint en Stripe apunte a la URL correcta
3. Revisar logs de Stripe Dashboard para ver errores de entrega

---

### **Problema: Aprovisionamiento de tenant falla**

**Error:** Script `create_tenant.sh` retorna error

**Diagnóstico:**
```bash
# Verificar que el script existe
pct exec 105 -- test -f /root/Cloudflare/create_tenant.sh && echo "Existe" || echo "No existe"

# Probar manualmente
pct exec 105 -- bash -c "cd /root/Cloudflare && ./create_tenant.sh testmanual"
```

**Solución:**
1. Verificar que LXC 105 esté corriendo
2. Confirmar que cloudflared esté autenticado en LXC 105
3. Verificar que PostgreSQL en LXC 105 tenga usuario `Jeturing`

---

### **Problema: NGINX retorna 502 Bad Gateway**

**Diagnóstico:**
```bash
pct exec 160 -- systemctl status nginx
pct exec 160 -- systemctl status onboarding
pct exec 160 -- tail -20 /var/log/nginx/error.log
```

**Solución:**
```bash
# Reiniciar ambos servicios
pct exec 160 -- bash -c "systemctl restart onboarding && sleep 2 && systemctl restart nginx"

# Verificar que FastAPI esté escuchando
pct exec 160 -- ss -tlnp | grep 4443
```

---

### **Problema: Base de datos no conecta**

**Error:** `psycopg2.OperationalError`

**Diagnóstico:**
```bash
pct exec 160 -- systemctl status postgresql
pct exec 160 -- psql -U jeturing -d onboarding_db -c "SELECT 1;"
```

**Solución:**
```bash
# Reiniciar PostgreSQL
pct exec 160 -- systemctl restart postgresql

# Verificar configuración de acceso
pct exec 160 -- cat /etc/postgresql/15/main/pg_hba.conf | grep jeturing

# Recrear base de datos si es necesario
pct exec 160 -- psql -U postgres -c "DROP DATABASE IF EXISTS onboarding_db;"
pct exec 160 -- psql -U postgres -c "CREATE DATABASE onboarding_db OWNER jeturing;"
```

---

## 📚 Próximos Pasos y Mejoras

### **Fase 1: MVP Operativo** ✅ (Completado)
- [x] Infraestructura LXC configurada
- [x] Base de datos PostgreSQL con esquema completo
- [x] API FastAPI con endpoints principales
- [x] Integración básica con Stripe
- [x] Aprovisionamiento manual de tenants Odoo
- [x] Interfaz web HTML básica
- [x] NGINX con SSL autofirmado

### **Fase 2: Producción Ready** (Pendiente)
- [ ] Configurar certificado SSL válido (Let's Encrypt)
- [ ] Configurar túnel Cloudflare público
- [ ] Activar cuenta Stripe en modo Live
- [ ] Implementar autenticación JWT para API
- [ ] Agregar rate limiting
- [ ] Configurar backups automáticos (PostgreSQL + filestore Odoo)
- [ ] Implementar sistema de logging centralizado
- [ ] Crear dashboard de administración

### **Fase 3: Features Avanzados** (Futuro)
- [ ] Sistema de emails automáticos (bienvenida, facturas, recordatorios)
- [ ] Portal de auto-servicio para clientes:
  - Cambiar plan
  - Actualizar método de pago
  - Ver historial de facturas
  - Gestionar usuarios
- [ ] Métricas y analytics (clientes, ingresos, churn)
- [ ] Integración con CRM (HubSpot, Salesforce)
- [ ] Multi-idioma (i18n)
- [ ] Custom branding por cliente
- [ ] API pública para integraciones externas
- [ ] Webhook outbound para notificar eventos

### **Fase 4: Escalabilidad** (Largo Plazo)
- [ ] Migrar a Kubernetes para auto-scaling
- [ ] Implementar CDN para assets estáticos
- [ ] Base de datos read replicas
- [ ] Cache layer (Redis) para sesiones
- [ ] Queue system (RabbitMQ/Celery) para tareas async
- [ ] Multi-region deployment
- [ ] Disaster recovery plan

---

## 📞 Soporte y Contacto

### **Acceso al Sistema**

**Host Proxmox:**
- **IP:** 172.16.16.0
- **Acceso:** SSH root

**LXC 160 - SRV-ONBOARDING:**
- **IP Interna:** 172.16.16.160
- **Usuario:** root
- **Contraseña:** 123Abcd
- **SSH:** `ssh root@172.16.16.160`

**PostgreSQL:**
- **Host:** 172.16.16.160
- **Puerto:** 5432
- **Usuario:** jeturing
- **Contraseña:** 321Abcd
- **Database:** onboarding_db

### **URLs Importantes**

- **Aplicación Web:** https://172.16.16.160/
- **API Health:** https://172.16.16.160/health
- **API Docs (futuro):** https://172.16.16.160/docs
- **Stripe Dashboard:** https://dashboard.stripe.com/test/dashboard
- **Odoo Tenants:** https://{subdomain}.sajet.us

---

## 📄 Licencia y Créditos

**Proyecto:** Sistema de Onboarding Automatizado  
**Desarrollado:** Enero 2026  
**Stack:** Python 3.11 + FastAPI + PostgreSQL + NGINX + Stripe  
**Infraestructura:** Proxmox LXC Containers  
**DNS/Tunneling:** Cloudflare  
**ERP:** Odoo 17 Community  

---

## 🔖 Changelog

### **v1.0.0 - 2026-01-12**
- ✅ Infraestructura base configurada
- ✅ API FastAPI con endpoints core
- ✅ Integración con Stripe (checkout + webhooks)
- ✅ Base de datos PostgreSQL con esquema completo
- ✅ Sistema de aprovisionamiento de tenants Odoo
- ✅ Interfaz web HTML con formulario de onboarding
- ✅ NGINX con SSL autofirmado (desarrollo)
- ✅ Servicio systemd con auto-restart
- ✅ Documentación completa

---

## 📊 Resumen Técnico

| Componente | Valor |
|------------|-------|
| **LXC ID** | 160 |
| **Hostname** | SRV-ONBOARDING |
| **IP Interna** | 172.16.16.160 |
| **RAM** | 1 GB |
| **Disco** | 10 GB |
| **OS** | Debian 12 |
| **Python** | 3.11.2 |
| **PostgreSQL** | 15.10 |
| **NGINX** | 1.22.1 |
| **Puerto API** | 4443 |
| **Puerto Web** | 443 (SSL) + 80 (HTTP) |
| **Puerto DB** | 5432 |
| **Usuario Root** | root:123Abcd |
| **Usuario DB** | jeturing:321Abcd |
| **Database** | onboarding_db |

---

**¡Sistema completamente operativo y listo para recibir credenciales de Stripe!**

Una vez configuradas las API keys de Stripe en `/opt/onboarding-system/.env`, el sistema estará listo para procesar pagos y aprovisionar tenants Odoo automáticamente.
